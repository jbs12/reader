#!/bin/bash
sudo apt-get update
sudo apt install git build-essential cmake libuv1-dev uuid-dev libmicrohttpd-dev libssl-dev -y
./xmrig-proxy